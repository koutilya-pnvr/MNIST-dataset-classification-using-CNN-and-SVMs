function net = cnnsetup_new(net, x, y) %setup the network
    assert(~isOctave() || compare_versions(OCTAVE_VERSION, '3.8.0', '>='), ['Octave 3.8.0 or greater is required for CNNs as there is a bug in convolution in previous versions. See http://savannah.gnu.org/bugs/?39314. Your version is ' myOctaveVersion]);
    
    assert(isfield(net,'loss'),'Loss function not defined.');
    assert(strcmp(net.loss,'L2')||strcmp(net.loss,'softmax'),'Unknown loss function "%s".',net.loss);

    for l = 1 : numel(net.layers)   %  layer
        assert(l~=numel(net.layers)||strcmp(net.layers{l}.type, 'fc'), 'Last layer must be fully-connected layer.');
        
        if strcmp(net.layers{l}.type,'input');
            mapsize = size(squeeze(x(:, :, 1)));
            inputmaps = 1;
        elseif strcmp(net.layers{l}.type, 'avgp')
            mapsize = mapsize / net.layers{l}.scale;
            assert(all(floor(mapsize)==mapsize), ['Layer ' num2str(l) ' size must be integer. Actual: ' num2str(mapsize)]);
            for j = 1 : inputmaps
                net.layers{l}.b{j} = 0;
            end
        elseif strcmp(net.layers{l}.type, 'maxp')
            mapsize = mapsize / net.layers{l}.scale;
            assert(all(floor(mapsize)==mapsize), ['Layer ' num2str(l) ' size must be integer. Actual: ' num2str(mapsize)]);
            for j = 1 : inputmaps
                net.layers{l}.b{j} = 0;
            end
        elseif strcmp(net.layers{l}.type, 'conv')
            mapsize = mapsize - net.layers{l}.kernelsize + 1;
            fan_out = net.layers{l}.outputmaps * net.layers{l}.kernelsize ^ 2;
            for j = 1 : net.layers{l}.outputmaps  %  output map
                fan_in = inputmaps * net.layers{l}.kernelsize ^ 2;
                for i = 1 : inputmaps  %  input map
                    net.layers{l}.k{i}{j} = (rand(net.layers{l}.kernelsize) - 0.5) * 2 * sqrt(6 / (fan_in + fan_out));
                    net.layers{l}.kh{i}{j} = zeros(net.layers{l}.kernelsize);
                end
                net.layers{l}.b{j} = 0;
                net.layers{l}.bh{j} = 0;
            end
            inputmaps = net.layers{l}.outputmaps;
        elseif strcmp(net.layers{l}.type, 'fc')
            
            assert(l~=numel(net.layers)||net.layers{l}.outputmaps==size(y, 1), 'Number of output nodes must be equal to the number of classes.');
            
            mapsize_prev = mapsize;
            mapsize = [1 1];
            onum = net.layers{l}.outputmaps;
            inum = prod(mapsize_prev)*inputmaps;
            
            net.layers{l}.k = (rand(onum, inum) - 0.5) * 2 * sqrt(6 / (onum + inum));
            net.layers{l}.kh = zeros(onum, inum);
            net.layers{l}.b = num2cell(zeros(onum, 1));
            net.layers{l}.bh = num2cell(zeros(onum, 1));
            
            inputmaps = net.layers{l}.outputmaps;
            
        else
            
            error('Layer %d unknown layer type "%s".',l,net.layers{l}.type);
            
        end
        
        
        if strcmp(net.layers{l}.type, 'conv')||strcmp(net.layers{l}.type, 'fc')
            
            if isfield(net.layers{l},'lr_mult') %learning rate multiplier
                
                if length(net.layers{l}.lr_mult)==1
                
                    net.layers{l}.lr_mult(2) = 1;
                
                end
                
            else
                
                net.layers{l}.lr_mult = [1 1]; %for weight and bias respectively
                
            end
            
            if isfield(net.layers{l},'decay_mult') %weight decay multiplier
                
                if length(net.layers{l}.decay_mult)==1
                
                    net.layers{l}.decay_mult(2) = 0;
                
                end
                
            else
                
                net.layers{l}.decay_mult = [0 0]; %for weight and bias respectively
                
            end
            
        end
                
    end
    
end
