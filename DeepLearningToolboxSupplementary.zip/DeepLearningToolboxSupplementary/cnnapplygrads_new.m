function net = cnnapplygrads_new(net, opts) %update weights and biases
    for l = 2 : numel(net.layers)
        if strcmp(net.layers{l}.type, 'conv')
            for j = 1 : numel(net.layers{l}.a)
                for ii = 1 : numel(net.layers{l - 1}.a)
                    %update history including gradient, weight decay and
                    %momentum
                    net.layers{l}.kh{ii}{j} = -opts.lr * net.layers{l}.lr_mult(1) * (net.layers{l}.dk{ii}{j} + opts.weight_decay * net.layers{l}.decay_mult(1) * net.layers{l}.k{ii}{j}) + opts.momentum * net.layers{l}.kh{ii}{j};
                    %update the weight
                    net.layers{l}.k{ii}{j} = net.layers{l}.k{ii}{j} + net.layers{l}.kh{ii}{j};
                end
                %update history including gradient, weight decay and
                %momentum
                net.layers{l}.bh{j} = -opts.lr * net.layers{l}.lr_mult(2) * (net.layers{l}.db{j} + opts.weight_decay * net.layers{l}.decay_mult(2) * net.layers{l}.b{j}) + opts.momentum * net.layers{l}.bh{j};
                %update the bias
                net.layers{l}.b{j} = net.layers{l}.b{j} + net.layers{l}.bh{j};
            end
        end
        if strcmp(net.layers{l}.type, 'fc')
            net.layers{l}.kh = -opts.lr * net.layers{l}.lr_mult(1) * (net.layers{l}.dk + opts.weight_decay * net.layers{l}.decay_mult(1) * net.layers{l}.k) + opts.momentum * net.layers{l}.kh;
            net.layers{l}.k= net.layers{l}.k + net.layers{l}.kh;
            
            for j = 1 : numel(net.layers{l}.a)
                net.layers{l}.bh{j} = -opts.lr * net.layers{l}.lr_mult(2) * (net.layers{l}.db{j} + opts.weight_decay * net.layers{l}.decay_mult(2) * net.layers{l}.b{j}) + opts.momentum * net.layers{l}.bh{j};
                net.layers{l}.b{j} = net.layers{l}.b{j} + net.layers{l}.bh{j};
            end
        end
    end
end
