function net = cnnff_new(net, x) %feed forward from input to output
    n = numel(net.layers);

    for l = 1 : n   %  for each layer
        
        if strcmp(net.layers{l}.type, 'input') %input layer
            net.layers{1}.a{1} = x;
            inputmaps = 1;
        elseif strcmp(net.layers{l}.type, 'conv') %convolutional layer
            %  !!below can probably be handled by insane matrix operations
            for j = 1 : net.layers{l}.outputmaps   %  for each output map
                %  create temp output map
                z = zeros(size(net.layers{l - 1}.a{1}) - [net.layers{l}.kernelsize - 1 net.layers{l}.kernelsize - 1 0]);
                for i = 1 : inputmaps   %  for each input map
                    %  convolve with corresponding kernel and add to temp output map
                    z = z + convn(net.layers{l - 1}.a{i}, net.layers{l}.k{i}{j}, 'valid');
                end
                %  add bias
                net.layers{l}.a{j} = z + net.layers{l}.b{j};
            end
            %  set number of input maps to this layers number of outputmaps
            inputmaps = net.layers{l}.outputmaps;
        elseif strcmp(net.layers{l}.type, 'fc') %fully-connected layer
            input = [];
            for j = 1 : numel(net.layers{l-1}.a)
                sa = size(net.layers{l-1}.a{j});
                input = [input; reshape(net.layers{l-1}.a{j}, sa(1) * sa(2), sa(3))];
            end
        %  feedforward into next layer
        	net.layers{l}.a = num2cell(shiftdim(net.layers{l}.k * input,-1),3);
            for j = 1 : net.layers{l}.outputmaps
                %  add bias
                net.layers{l}.a{j} = net.layers{l}.a{j} + net.layers{l}.b{j};
            end
            %  set number of input maps to this layers number of outputmaps
            inputmaps = net.layers{l}.outputmaps;
        elseif strcmp(net.layers{l}.type, 'avgp') %average pooling layer
            %  downsample
            for j = 1 : inputmaps
                z = convn(net.layers{l - 1}.a{j}, ones(net.layers{l}.scale) / (net.layers{l}.scale ^ 2), 'valid');   %  !! replace with variable
                net.layers{l}.a{j} = z(1 : net.layers{l}.scale : end, 1 : net.layers{l}.scale : end, :);
            end
        elseif strcmp(net.layers{l}.type, 'maxp') %max pooling layer
            %  downsample
            
            for j = 1 : inputmaps
                sa = size(net.layers{l-1}.a{j});
                
                M = sa(1) / net.layers{l}.scale;
                N = sa(2) / net.layers{l}.scale;
                
                net.layers{l}.a{j} = zeros(M,N,sa(3));
                net.layers{l}.m_mask{j} = zeros(sa);
                
                z = zeros(M,N,sa(3),net.layers{l}.scale^2);
                
                for mm = 1:net.layers{l}.scale
                    for nn = 1:net.layers{l}.scale
                        z(:,:,:,(mm-1)*net.layers{l}.scale+nn) = net.layers{l-1}.a{j}(mm:net.layers{l}.scale:sa(1),nn:net.layers{l}.scale:sa(2),:);
                    end
                end
                
                [z_max,~] = max(z,[],4);
                
                [z_min,~] = min(-z,[],4);
                
                idx = z_max >= - z_min;
               
                net.layers{l}.a{j}(idx) = z_max(idx);
                net.layers{l}.a{j}(not(idx)) = z_min(not(idx)); %finding indices with maximal absolute value
                
                m_mask = z == repmat(z_max,[1 1 1 4]);
                
                m_mask = m_mask ./ repmat(sum(m_mask,4),[1 1 1 4]); %max pooling mask
                
                for mm = net.layers{l}.scale
                    for nn = net.layers{l}.scale
                        net.layers{l}.m_mask{j}(mm:net.layers{l}.scale:sa(1),nn:net.layers{l}.scale:sa(2),:) = m_mask(:,:,:,(mm-1)*net.layers{l}.scale+nn);
                    end
                end
            end
        end
        if isfield(net.layers{l},'func')
            if strcmp(net.layers{l}.func, 'sigm') %sigmoid function

                for j = 1 : net.layers{l}.outputmaps

                    net.layers{l}.a{j}=sigm(net.layers{l}.a{j});

                end

            elseif strcmp(net.layers{l}.func, 'relu') %ReLU function
                
                for j = 1 : net.layers{l}.outputmaps

                    net.layers{l}.sign{j}=net.layers{l}.a{j}>=0;

                    net.layers{l}.a{j}=max(net.layers{l}.a{j},0); %cut the negative part

                end

            end
        end
        %If activation function is not defined, do nothing
    end
    sa = size(net.layers{l}.a{1});
    net.o = reshape(cat(3,net.layers{l}.a{:}),sa(3),[])'; %output 

end
