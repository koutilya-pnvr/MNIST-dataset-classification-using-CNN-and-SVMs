function [er, bad] = cnntest_new(net, x, y)
    %  feedforward
    net = cnnff_new(net, x);
    if strcmp(net.loss,'L2')
        [~, h] = max(net.o);
    elseif strcmp(net.loss,'softmax')
        omax = max(net.o);
        o2 = net.o-repmat(omax,size(net.o,1),1);
        o2 = exp(o2);
        o2 = o2./repmat(sum(o2,1),size(net.o,1),1);
        [~, h] = max(o2);
    end
    [~, a] = max(y);
    bad = find(h ~= a);

    er = numel(bad) / size(y, 2);
end
