1. Please first copy cnnapplygrads_new.m, cnnbp_new.m, cnnff_new.m, cnnsetup_new.m, cnntest_new.m and cnntrain_new.m into DeepLearnToolbox/CNN. Now you can use these new functions to build a more powerful CNN.

cnnsetup_new: Setup new CNN.

cnnff_new: CNN feed forward.

cnn_bp_new: CNN back propagation.

cnnapplygrads_new: Update weights and biases.

cnntrain_new: Train CNN based on new functions.

cnntest_new: Test CNN based on new functions.

2. After downloading the MNIST dataset (which are binary files), you can use loadMNISTImages.m and loadMNISTLabels.m to read data.

3. In the toolbox, a CNN network is defined as a structure. The structure has fields called ‘layers’ and ‘loss’. ‘layers’ is a cell of structures. Each element of ’layers’ is a structure which defines the type and some parameters of this layer. ‘loss’ defines the loss function of the whole network.

Currently there're 6 layer types:
‘input’: Input layer. Contains the input data.
‘conv’: Convolutional layer. ‘Outputmaps’ is the number of output channels for the layer, i.e. the number of filters. ‘kernelsize’ is the size of the convolutional kernel. ‘lr_mult’ are the local multipliers of the learning rate for weights and bias respectively (default [1 1]). ‘weight_decay_mult’ are the local multipliers of the weight decay for weights and bias respectively (default [0 0]). ‘func’ defines the activation function for the layer. Now you can choose from ’sign’, sigmoid function, ’relu’, ReLU function or linear (default).
‘fc’: Fully-connected layer. Similar to ‘conv’ layers except there’s no ‘kernelsize’ option. 
‘maxp’: Max pooling layer. ‘scale’ is the pooling scale, i.e. the output size will be the input size scaled by this factor.
‘avgp’: Average pooling layer. Similar to ‘maxp’ layers.

We also have 2 loss function types:
‘L2’: L2 loss function. If you use this loss function, your output layer should use sigmoid function as activation.
‘softmax’: Softmax loss function. If you use this loss function , your output layer should use the default linear activation function.
For both loss functions, the ground truth output should be in the form like [0 0 0 1 0 0]^T if there’re 6 classes and your label is 4.

4. After the CNN is built, you need to define a solver. Solver parameters are controlled by a structure called ‘opts’.
There’re 5 fields of ‘opts’ that you can modify:
‘lr’: Learning rate.
‘momentum’: Learning momentum.
‘weight_decay’: Weight decay.
‘batchsize’: Number of samples you use in each iteration.
‘numepochs’: Number of epochs you run in total.
Please read http://caffe.berkeleyvision.org/tutorial/solver.html to see the definition of these parameters.

5. MNIST_example.m is a small example of how to train and test a CNN.
