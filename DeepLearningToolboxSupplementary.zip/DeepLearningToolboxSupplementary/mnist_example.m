clear;
clc;

addpath(genpath('DeepLearnToolbox'));

%% Prepare Training and Testing Data

train_x=loadMNISTImages('MNIST/train-images-idx3-ubyte');
train_label=loadMNISTLabels('MNIST/train-labels-idx1-ubyte');

test_x=loadMNISTImages('MNIST/t10k-images-idx3-ubyte');
test_label=loadMNISTLabels('MNIST/t10k-labels-idx1-ubyte');
%loading data, if you put your data in ./MNIST

train_x=reshape(train_x,28,28,[]);
test_x=reshape(test_x,28,28,[]); %training and testing samples

train_y=zeros(10,length(train_label));
test_y=zeros(10,length(test_label));

step_train=0:10:10*length(train_label)-1;
train_y(train_label'+step_train+1)=1;

step_test=0:10:10*length(test_label)-1;
test_y(test_label'+step_test+1)=1; %training and testing labels



%% Define a Convolutional Neural Network 


rand('state',0)

cnn.layers = {
    struct('type', 'input')
    %input layer
    struct('type', 'conv', 'outputmaps', 5, 'kernelsize', 5 ,'func','sigm')
    %convolutional layer with 5 output channels and 5x5 kernels, sigmoid activation function
    struct('type', 'avgp', 'scale', 2)
    %average pooling layer with pooling scale 2
    struct('type', 'conv', 'outputmaps', 10, 'kernelsize', 5 ,'func','relu')
    %convolutional layer with 10 output channels and 5x5 kernels, ReLU activation function
    struct('type', 'maxp', 'scale', 2)
    %max pooling layer with pooling scale 2
    struct('type', 'fc', 'outputmaps', 10)
    %fully-connected layer with 10 output channels, linear activation function
};

cnn.loss = 'softmax';
%softmax loss function

%% Define the Solver

opts.lr = 1; %learning rate
opts.momentum = 0; %learning momentum
opts.weight_decay = 0; %weight decay
opts.batchsize = 50; %batch size
opts.numepochs = 1; %number of epochs

%% Start Training

cnn = cnnsetup_new(cnn, train_x, train_y); %set up the CNN network
cnn = cnntrain_new(cnn, train_x, train_y, opts); % train the CNN newwork using the training data

%% Start Testing

[er, ~] = cnntest_new(cnn, test_x, test_y); % test the CNN network using the testing data

%% Output Results

%plot mean squared error
figure; plot(cnn.rL);
fprintf('Error=%f\n',er);
