function net = cnntrain_new(net, x, y, opts)
    m = size(x, 3);
    numbatches = ceil(m / opts.batchsize);   
    net.rL = [];
    tic;
    for i = 1 : opts.numepochs
        disp(['epoch ' num2str(i) '/' num2str(opts.numepochs)]);
        kk = randperm(m);
        for l = 1 : numbatches
            
            batch_x = x(:, :, kk(mod((l - 1) * opts.batchsize: l * opts.batchsize-1,m)+1));
            batch_y = y(:,    kk(mod((l - 1) * opts.batchsize: l * opts.batchsize-1,m)+1));

            net = cnnff_new(net, batch_x);
            net = cnnbp_new(net, batch_y);
            net = cnnapplygrads_new(net, opts); %do forwarding, backproping and updating for each batch
            if isempty(net.rL)
                net.rL(1) = net.L;
            end
            net.rL(end + 1) = 0.99 * net.rL(end) + 0.01 * net.L;
            fprintf('Epoch %d batch %d Loss=%f\n',i,l,net.L);
        end
    end
    toc;
    
end
