function net = cnnbp_new(net, y) %back propagation from output to input
    n = numel(net.layers);

    if strcmp(net.loss,'L2')
        
        net.e = net.o - y;
        %  L2 loss function
        net.L = 1/2* sum(net.e(:) .^ 2) / size(net.e, 2);
        
        net.od = net.e; %gradient of L2
        
    elseif strcmp(net.loss,'softmax')
        
        omax = max(net.o,[],1);
        o2 = net.o-repmat(omax,size(net.o,1),1);
        o2 = exp(o2);
        net.e = o2./repmat(sum(o2,1),size(net.o,1),1);
        
        %  softmax loss function
        net.L = - sum(log(net.e(boolean(y)))) / size(net.e, 2);
        
        net.od = net.e;
        net.od(boolean(y)) = net.od(boolean(y))-1; %gradient of softmax
        
    end
    
    for j = 1 : numel(net.layers{n}.a)
        net.layers{n}.d{j} = reshape(net.od(j,:),1,1,[]); %reshape the gradient of last layer's output
    end
    
    if isfield(net.layers{n},'func')
        if strcmp(net.layers{n}.func,'sigm')
            for j = 1 : numel(net.layers{n}.a)
                net.layers{n}.d{j} = net.layers{n}.a{j} .* (1 - net.layers{n}.a{j}) .*net.layers{n}.d{j};
            end
        elseif strcmp(net.layers{n}.func,'relu')
            for j = 1 : numel(net.layers{n}.a)
                net.layers{n}.d{j} = net.layers{n}.sign{j} .*net.layers{n}.d{j}; 
            end
        end %gradient of last layers's network output
    end

    for l = (n - 1) : -1 : 1
        if strcmp(net.layers{l+1}.type, 'conv')
            for i = 1 : numel(net.layers{l}.a)
                z = zeros(size(net.layers{l}.a{1}));
                for j = 1 : numel(net.layers{l + 1}.a)
                     z = z + convn(net.layers{l + 1}.d{j}, rot180(net.layers{l + 1}.k{i}{j}), 'full');
                end
                net.layers{l}.d{i} = z;
            end
        elseif strcmp(net.layers{l+1}.type, 'fc')
            sa = size(net.layers{l}.a{1});
            d = reshape(net.layers{l+1}.k'*reshape(cat(3,net.layers{l+1}.d{:}),sa(3),[])',[],sa(3));
            for j = 1 : numel(net.layers{l}.a)
                net.layers{l}.d{j} = reshape(d((j-1)*sa(1)*sa(2)+1:j*sa(1)*sa(2),:),sa(1),sa(2),[]);
            end
                
        elseif strcmp(net.layers{l+1}.type, 'avgp')
            for j = 1 : numel(net.layers{l}.a)
                net.layers{l}.d{j} = (expand(net.layers{l + 1}.d{j}, [net.layers{l + 1}.scale net.layers{l + 1}.scale 1]) / net.layers{l + 1}.scale ^ 2);
            end
        elseif strcmp(net.layers{l+1}.type, 'maxp')
            for j = 1 : numel(net.layers{l}.a)
                net.layers{l}.d{j} = (expand(net.layers{l + 1}.d{j}, [net.layers{l + 1}.scale net.layers{l + 1}.scale 1])) .* net.layers{l+1}.m_mask{j};
            end
        end %gradient of each layer's output
        
        if isfield(net.layers{l},'func')
            if strcmp(net.layers{l}.func,'sigm')
                for j = 1 : numel(net.layers{l}.a)
                    net.layers{l}.d{j} = net.layers{l}.a{j} .* (1 - net.layers{l}.a{j}) .*net.layers{l}.d{j};
                end
            elseif strcmp(net.layers{l}.func,'relu')
                for j = 1 : numel(net.layers{l}.a)
                    net.layers{l}.d{j} = net.layers{l}.sign{j} .*net.layers{l}.d{j};
                end
            end
        end %gradient of each layer's network output
            
    end

    %%  calc gradients
    for l = 2 : n
        if strcmp(net.layers{l}.type, 'conv')
            for j = 1 : numel(net.layers{l}.a)
                for i = 1 : numel(net.layers{l - 1}.a)
                    net.layers{l}.dk{i}{j} = convn(flipall(net.layers{l - 1}.a{i}), net.layers{l}.d{j}, 'valid') / size(net.layers{l}.d{j}, 3);
                end
                net.layers{l}.db{j} = sum(net.layers{l}.d{j}(:)) / size(net.layers{l}.d{j}, 3);
            end
        elseif strcmp(net.layers{l}.type, 'fc')
            sa = size(net.layers{l}.a{1});
            input=[];
            for j = 1 : numel(net.layers{l}.a)
                net.layers{l}.db{j} = sum(net.layers{l}.d{j}(:))/ size(net.layers{l}.d{j}, 3);
            end
            for i = 1 : numel(net.layers{l-1}.a)
                input=[input;reshape(net.layers{l - 1}.a{i},[],sa(3))];
            end
            net.layers{l}.dk = reshape(cat(3,net.layers{l}.d{:}),sa(3),[])'*input'/ size(net.layers{l}.d{j}, 3);
        end
    end %gradient of each layer's weights and biases.

    function X = rot180(X)
        X = flipdim(flipdim(X, 1), 2);
    end
end
